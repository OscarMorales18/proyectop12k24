#ifndef REGISTRO_H
#define REGISTRO_H


class Registro
{
    public:
        void menuR();

    protected:

    private:

};

#endif // REGISTRO_H
